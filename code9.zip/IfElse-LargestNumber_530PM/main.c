#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    if(a > b)
    {
        printf("A is greater than B");
    }
    else
    {
        printf("B is greater than A");
    }

    return 0;
}

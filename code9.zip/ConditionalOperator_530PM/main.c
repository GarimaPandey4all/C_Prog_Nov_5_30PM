#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    (a > b) ? printf("A is greater than B") : printf("B is greater than A");

    return 0;
}

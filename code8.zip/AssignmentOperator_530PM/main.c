#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 40;

    a += 50;//shorthand // a = a + 50;

    printf("A is: %d\n", a);

    //a /= 23; // a = a / 23;

    a = a / 23;

    printf("A is: %d\n", a);

    return 0;
}

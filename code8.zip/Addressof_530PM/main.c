#include <stdio.h>
#include <stdlib.h>

//&a, &b

int main()
{
    int ch = 35;
    char c = 'E';

    printf("address of ch: %u\n", &ch);

    printf("address of c: %u\n", &c);

    return 0;
}

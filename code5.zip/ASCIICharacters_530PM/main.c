#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;

    printf("Enter any number:\n");
    scanf("%d", &a);

    printf("You entered number's character value is: %c", a);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

int main()
{
    //clrscr();
    printf("Hello world!\n");
    getch();
    return 0;
}

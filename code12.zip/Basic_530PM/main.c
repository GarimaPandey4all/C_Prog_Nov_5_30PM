#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;

    for(i = 1; i <= 10; i++)
    {
        printf("Hello world!\n");
    }

    return 0;
}

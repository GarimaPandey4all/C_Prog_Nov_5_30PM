#include <stdio.h>
#include <stdlib.h>

/*
    a, b, c

    1. a > b && a > c
    2. b > c
    3. c

*/

int main()
{
    int a, b, c;

    printf("Enter any value for a, b and c:");
    scanf("%d %d %d", &a, &b, &c);

    if(a > b && a > c)
    {
        printf("A is greater");
    }
    else if(b > c)
    {
        printf("B is greater");
    }
    else
    {
        printf("C is greater");
    }

    return 0;
}

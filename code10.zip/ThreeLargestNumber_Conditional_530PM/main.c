#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, result;

    printf("Enter any value for a, b and c:");
    scanf("%d %d %d", &a, &b, &c);

    //Nested Conditional operator
    result = (a > b && a > c) ? a : ((b > c) ? b : c);

    printf("Largest number is: %d", result);

    return 0;
}

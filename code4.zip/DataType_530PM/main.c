#include <stdio.h>
#include <stdlib.h>

int main()
{
    //unsigned short int a = 65537;

    //signed short int a = 65535;

    signed short int a = 32768;

    //printf("A is: %u\n", a);

    printf("A is: %d", a);

    return 0;
}

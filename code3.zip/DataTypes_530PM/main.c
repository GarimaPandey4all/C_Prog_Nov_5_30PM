#include <stdio.h>
#include <stdlib.h>

/*
    10 - integer/numeric number
    50.78 - Floating - point numbers
    45.989808095 - Floating - point numbers
    M - Character Type
    Harish - String Type : more than one character: word or sentence
*/

/*
    Primitive: Pre-defined Data types

    Derived: Derived from primitive data type

*/

void main() // void : null or empty: no return type
{

    // 1 byte = 8 bits

    int a = 10; // int - 2 or 4 bytes

    float b = 50.78f; // 4 bytes

    double c = 45.989808095; // 8 bytes

    char d = 'M'; // 1 byte

    printf("A is: %d\n", a);

    printf("B is: %.2f\n", b);

    printf("C is: %lf\n", c);

    printf("C is: %c\n", d);

    //return 'O';

    //Sizeof operator

    printf("Size of int: %d\n", sizeof(a));
    printf("Size of float: %d\n", sizeof(b));
    printf("Size of double: %d\n", sizeof(c));
    printf("Size of char: %d\n\n", sizeof(d));

    printf("Size of int: %d\n", sizeof(int));
    printf("Size of float: %d\n", sizeof(float));
    printf("Size of double: %d\n", sizeof(double));
    printf("Size of char: %d\n", sizeof(char));
}

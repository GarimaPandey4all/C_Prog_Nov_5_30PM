#include <stdio.h>
#include <stdlib.h>

int main()
{
    //variable - vary or change

    int a = 10, b = 20, c; // variable declaration/create and initialization/define/assign
    //int a;

    const int aa = 10; // const = constant = variable with fixed value

    c = a + b;

    printf("Addition is: %d\n\n", c); // Semicolon = ; - terminator / terminate/end the line
    //\n - new line character
    a = 15;

    c = a + b;

    printf("Addition is: %d", c);

    //aa = 20; // error

    return 0;
}

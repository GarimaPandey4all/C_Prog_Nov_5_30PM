#include <stdio.h>
#include <stdlib.h>

int main()
{
    const float pi = 3.14; // 22/7

    const int month = 12;

    month = 14;

    /*

    *********C - Program

    */

    return 0;
}

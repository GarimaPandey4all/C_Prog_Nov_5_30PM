#include <stdio.h>
#include <stdlib.h>

/*
    &&- AND Logical

    ||- OR Logical

    !- Not Logical

*/

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("AND Logical Operator: %d\n", (a > b && b < 4)); // 0
    printf("OR Logical Operator: %d\n", (a > b || b < 4)); // 1
    printf("Not Logical Operator: %d\n", !(a > b && b < 4)); // 1

    return 0;
}

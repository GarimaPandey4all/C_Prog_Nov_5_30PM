#include <stdio.h>
#include <stdlib.h>

// (a + b / c) - Mathematical Expression
// Operators: + and /
// Operands: a, b, and c

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b); // a = 4, b = 5

    printf("Addition is: %d\n", (a + b)); // 9
    printf("Subtraction is: %d\n", (a - b)); // -1
    printf("Multiplication is: %d\n", (a * b)); // 20
    printf("Division is: %d\n", (a / b)); // 0
    printf("Modulus Operator is: %d\n", (a % b)); //  4 % 5 = 4

    // a = 4
    printf("Pre-Increment: %d\n", ++a); // a= 5
    printf("Post-Increment: %d\n", a++); // a = 5
    printf("a is: %d\n", a);

    // b = 5
    printf("Pre-Decrement: %d\n", --b); // 5 - 1 = 4
    printf("Post-Decrement: %d\n", b--); // 4
    printf("b is: %d\n", b); // b = 3

    return 0;
}

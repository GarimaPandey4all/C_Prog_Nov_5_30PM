#include <stdio.h>
#include <stdlib.h>

/*
    Switch: Menu Driven Program

    break: jump out from the current block
*/

int main()
{
    int choice;
    int a, b;

    printf("\n\nPress 1. Addition");
    printf("\nPress 2. Subtraction");
    printf("\nPress 3. Multiplication");
    printf("\nPress 4. Division");

    printf("\n\nEnter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Addition is: %d\n", (a + b));
        break;

    case 2:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Subtraction is: %d\n", (a - b));
        break;

    case 3:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Multiplication is: %d\n", (a * b));
        break;

    case 4:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Division is: %d\n", (a / b));
        break;

    default:
        printf("Invalid Choice");
    }

    //printf("Outside Switch Block");

    return 0;
}

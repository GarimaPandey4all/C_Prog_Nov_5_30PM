#include <stdio.h>
#include <stdlib.h>

int main()
{
    int choice;
    int a, b;

    while(1) // 1 = true // infinite while loop/repeatation
    {

    printf("\n\nPress 1: X-OR");
    printf("\nPress 2: Left Shift");
    printf("\nPress 3: Right Shift");
    printf("\nPress 4: Even-Odd");
    printf("\nPress 5: Exit"); // Exit the Program

    printf("\n\nEnter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("X-OR is: %d", (a ^ b));
        break;

    case 2:
        printf("Enter value for a:");
        scanf("%d", &a);

        printf("Left Shift is: %d", (a << 2));
        break;

    case 3:
        printf("Enter value for a:");
        scanf("%d", &a);

        printf("Right Shift is: %d", (a >> 2));
        break;

    case 4:
        printf("Enter value for a:");
        scanf("%d", &a);

        ((a % 2) == 0) ? printf("Number is Even"):printf("Number is Odd");
        break;

    case 5:
        exit(0);

    default:
        printf("Invalid Choice");

    }
    }

    return 0;
}

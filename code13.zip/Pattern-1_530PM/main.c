#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    //Nested Loops
    for(i = 1; i <= 5; i++) // i = rows = 5
    {
        for(j = 1; j <= 5; j++) // j = columns = 5
        {
            //printf("*");
            //printf("%d", j);
            printf("%d", i);
        }
        printf("\n");
    }

    return 0;
}

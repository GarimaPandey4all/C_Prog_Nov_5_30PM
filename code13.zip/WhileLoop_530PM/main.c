#include <stdio.h>
#include <stdlib.h>

/*
    while(1)
    {}

    for(;;)
    {}

*/

int main()
{
    int i = 1;

    while(i <= 10)
    {
        printf("%d\n", i);
        i++;
    }

    return 0;
}

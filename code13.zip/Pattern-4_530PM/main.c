#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    //Nested Loops
    for(i = 5; i >= 1; i--) // i = rows = 5
    {
        for(j = 5; j >=1; j--) // j = columns = 5
        {
            printf("%d", j);
            //printf("%d", i);
        }
        printf("\n");
    }

    return 0;
}

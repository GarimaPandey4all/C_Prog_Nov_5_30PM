#include <stdio.h>
#include <stdlib.h>

// ASCII Characters: A- 65 to Z- 90 and a - 97 to z - 122

int main()
{
    int i, j;

    for(i = 65; i <= 69; i++)
    {
        for(j = 65; j <= 69; j++)
        {
            //printf("%c", j);
            printf("%c", i);
        }
        printf("\n");
    }

    return 0;
}
